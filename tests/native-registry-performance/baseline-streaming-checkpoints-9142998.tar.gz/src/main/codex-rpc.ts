import type { ClientChannel } from 'ssh2'
import { Cause, Deferred, Effect, Exit, Option, Schema, type Scope } from 'effect'
import { JsonLines } from './json-lines'
import { runEffect } from './effect-runtime'

type Wire = Record<string, unknown>
const uncertainMutations = new Set(['initialize', 'thread/start', 'thread/resume', 'turn/start'])
const decodeWire = Schema.decodeUnknownOption(Schema.Record(Schema.String, Schema.Unknown))
const decodeRemoteError = Schema.decodeUnknownOption(
  Schema.Struct({
    message: Schema.optionalKey(Schema.String),
    code: Schema.optionalKey(Schema.Number),
  }),
)

export class CodexRequestError extends Schema.TaggedError<CodexRequestError>()(
  'CodexRequestError',
  {
    method: Schema.String,
    message: Schema.String,
    code: Schema.optionalKey(Schema.Number),
  },
) {
  constructor(method: string, message: string, code?: number) {
    super({ method, message, ...(code === undefined ? {} : { code }) })
  }
}

export class CodexRequestCancelled extends Schema.TaggedError<CodexRequestCancelled>()(
  'CodexRequestCancelled',
  { method: Schema.String, message: Schema.String },
) {
  constructor(method: string) {
    super({ method, message: 'Codex request cancelled' })
  }
}

export class CodexTransportError extends Schema.TaggedError<CodexTransportError>()(
  'CodexTransportError',
  { message: Schema.String, cause: Schema.Defect() },
) {
  constructor(cause: unknown) {
    super({ message: cause instanceof Error ? cause.message : String(cause), cause })
  }
}

export type CodexRPCError = CodexRequestError | CodexRequestCancelled | CodexTransportError

export class CodexRPC {
  private next = 1
  private failure?: CodexTransportError
  private stderr = ''
  private startupOutput = ''
  private suspended = false
  private pending = new Map<
    number,
    {
      method: string
      result: Deferred.Deferred<Wire, CodexRPCError>
      cleanup: () => void
      timer?: NodeJS.Timeout
      remaining: number
      started: number
      expire: () => void
    }
  >()
  constructor(
    readonly channel: ClientChannel,
    receive: (message: Wire) => void,
    private onFailure: (error: Error) => void = () => {},
  ) {
    this.suspended =
      (channel as ClientChannel & { transportState?: string }).transportState === 'suspended'
    channel.on('suspended', () => {
      if (this.suspended) return
      this.suspended = true
      for (const pending of this.pending.values()) {
        clearTimeout(pending.timer)
        pending.timer = undefined
        pending.remaining = Math.max(1, pending.remaining - (Date.now() - pending.started))
      }
    })
    channel.on('resumed', () => {
      if (!this.suspended || this.failure) return
      this.suspended = false
      for (const pending of this.pending.values()) {
        pending.started = Date.now()
        pending.timer = setTimeout(pending.expire, pending.remaining)
      }
    })
    const lines = new JsonLines(
      (message) => {
        if (this.failure) return
        if (typeof message.id === 'number' && !message.method) {
          const pending = this.pending.get(message.id)
          // Responses to cancelled requests are not server notifications.
          if (!pending) return
          this.pending.delete(message.id)
          pending.cleanup()
          if (message.error) {
            const error = Option.getOrElse(decodeRemoteError(message.error), () => ({
              message: undefined,
              code: undefined,
            }))
            Deferred.doneUnsafe(
              pending.result,
              Effect.fail(
                new CodexRequestError(
                  pending.method,
                  error.message || 'Codex request failed',
                  error.code,
                ),
              ),
            )
          } else
            Deferred.doneUnsafe(
              pending.result,
              Effect.succeed(Option.getOrElse(decodeWire(message.result), () => ({}))),
            )
        } else receive(message)
      },
      (line) => {
        // Login shells can print banners before exec reaches app-server. Keep
        // those separate from JSON framing failures and accept the handshake.
        if (line !== 'Agent output exceeded the message limit' && !/^\s*[\[{]/.test(line)) {
          this.startupOutput = (this.startupOutput + '\n' + line.slice(0, 2048)).slice(-8192)
          return
        }
        this.close(
          new Error(
            line === 'Agent output exceeded the message limit'
              ? 'Codex returned a response larger than the protocol limit. Update the remote Codex installation and retry; your saved conversation is unchanged.'
              : 'Codex returned an invalid protocol message. Retry, or check the remote Codex installation and shell startup output.',
          ),
        )
      },
    )
    channel.on('data', (chunk: Buffer) => lines.push(chunk))
    channel.stderr.on('data', (chunk: Buffer) => {
      this.stderr = (this.stderr + chunk.toString()).slice(-8192)
    })
    channel.on('error', (error: Error) => this.close(error))
    channel.on('close', () => {
      this.fail(
        this.failure ||
          new Error(this.stderr || 'Codex disconnected. Retry to reopen your saved conversation.'),
      )
    })
  }
  get closed() {
    return Boolean(this.failure) || this.channel.destroyed
  }
  send(message: Wire) {
    if (this.closed)
      throw this.failure || new CodexTransportError(new Error('Codex is disconnected'))
    this.channel.write(JSON.stringify(message) + '\n')
  }
  request(method: string, params: Wire = {}, timeout = 60000, signal?: AbortSignal): Promise<Wire> {
    return runEffect(this.requestEffect(method, params, timeout, signal))
  }
  readonly requestEffect = Effect.fnUntraced(
    function* (
      this: CodexRPC,
      method: string,
      params: Wire = {},
      timeout = 60000,
      signal?: AbortSignal,
    ): Effect.fn.Return<Wire, CodexRPCError, Scope.Scope> {
      if (signal?.aborted) return yield* new CodexRequestCancelled(method)
      if (this.closed)
        return yield* this.failure || new CodexTransportError(new Error('Codex is disconnected'))
      const id = this.next++
      const result = yield* Deferred.make<Wire, CodexRPCError>()
      let sent = false
      const cancel = () => {
        const uncertain = sent && !Deferred.isDoneUnsafe(result) && uncertainMutations.has(method)
        const error = new CodexRequestCancelled(method)
        cleanup()
        if (uncertain) this.close(error)
        Deferred.doneUnsafe(result, Effect.fail(error))
      }
      const expire = () => {
        cleanup()
        const error = new CodexRequestError(
          method,
          `${method} did not respond within ${Math.round(timeout / 1000)} seconds. ` +
            (method === 'thread/resume'
              ? 'Your saved conversation is unchanged. Retry to restart Codex; check remote Codex or required MCP server startup if this continues.'
              : method === 'turn/start'
                ? 'The Codex connection was stopped to avoid leaving an untracked turn running. Your saved conversation is unchanged; retry to resume it.'
                : 'Retry, or check the remote Codex installation and server startup.') +
            (this.stderr
              ? `\nRemote diagnostic: ${this.stderr.trim().slice(-2000)}`
              : this.startupOutput
                ? '\nThe remote login shell printed non-protocol output. Check its startup configuration.'
                : ''),
        )
        Deferred.doneUnsafe(result, Effect.fail(error))
        // A timed-out mutation may still be running remotely. Do not reuse the
        // stream or replay a user prompt against an uncertain thread state.
        if (uncertainMutations.has(method)) this.close(error)
      }
      const cleanup = () => {
        this.pending.delete(id)
        clearTimeout(pending.timer)
        signal?.removeEventListener('abort', cancel)
      }
      const pending = {
        method,
        result,
        cleanup,
        remaining: timeout,
        started: Date.now(),
        expire,
        timer: undefined as NodeJS.Timeout | undefined,
      }
      yield* Effect.acquireRelease(
        Effect.sync(() => {
          this.pending.set(id, pending)
          // Only connected time counts against this deadline. The durable
          // broker can keep the same request alive through an SSH interruption.
          if (!this.suspended) pending.timer = setTimeout(expire, timeout)
          signal?.addEventListener('abort', cancel, { once: true })
        }),
        (_, exit) =>
          Effect.sync(() => {
            const interrupted = Exit.isFailure(exit) && Cause.hasInterrupts(exit.cause)
            const uncertain =
              sent && !Deferred.isDoneUnsafe(result) && uncertainMutations.has(method)
            cleanup()
            // The remote mutation may have been accepted even if its response
            // has not arrived. Never leave that work on a reusable transport.
            if (interrupted && uncertain) this.close(new CodexRequestCancelled(method))
          }),
      )
      if (signal?.aborted) return yield* new CodexRequestCancelled(method)
      yield* Effect.try({
        try: () => {
          sent = true
          this.send({ id, method, params })
        },
        catch: (error) =>
          error instanceof CodexTransportError ? error : new CodexTransportError(error),
      })
      return yield* Deferred.await(result)
    }.bind(this),
    Effect.scoped,
  )
  close(error = new Error('Codex connection closed')) {
    if (this.failure) return
    this.fail(error)
    try {
      this.channel.signal('TERM')
    } catch {}
    try {
      this.channel.close()
    } catch {}
  }
  private fail(error: Error) {
    if (this.failure) return
    this.failure = error instanceof CodexTransportError ? error : new CodexTransportError(error)
    for (const pending of this.pending.values()) {
      pending.cleanup()
      Deferred.doneUnsafe(pending.result, Effect.fail(this.failure))
    }
    this.pending.clear()
    this.onFailure(error)
  }
}
