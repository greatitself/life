import { mkdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { Array as EffectArray, Effect, Schema } from 'effect'
import type {
  ConversationCheckpointAck,
  ConversationHistorySnapshot,
} from '../shared/conversations'
import { CONVERSATION_CHECKPOINT_BASE_CHANGED } from '../shared/conversations'
import {
  atomicSnapshot,
  PersistenceError,
  persistenceError,
  persistenceIO,
} from './persistence-effects'

const identitySchema = Schema.Struct({
  id: Schema.NonEmptyString,
  profileId: Schema.String,
  provider: Schema.Literals(['codex', 'claude']),
})
const metadataSchema = Schema.StructWithRest(identitySchema, [
  Schema.Record(Schema.String, Schema.Unknown),
])
const threadSchema = Schema.StructWithRest(
  Schema.Struct({
    ...identitySchema.fields,
    id: Schema.String,
    messages: Schema.Array(Schema.Unknown),
  }),
  [Schema.Record(Schema.String, Schema.Unknown)],
)
const historySchema = Schema.Array(threadSchema)
const timestampSchema = Schema.Int.check(Schema.isGreaterThanOrEqualTo(0))
const snapshotSchema = Schema.Struct({
  version: Schema.Literals([1]),
  savedAt: timestampSchema,
  threads: historySchema,
})
const orderSchema = Schema.Array(Schema.NonEmptyString).check(Schema.isUnique())
const identifiedMessageSchema = Schema.StructWithRest(
  Schema.Struct({ id: Schema.NonEmptyString }),
  [Schema.Record(Schema.String, Schema.Unknown)],
)
const messageFieldSchema = Schema.Struct({
  id: Schema.NonEmptyString,
  set: Schema.Record(Schema.String, Schema.Unknown),
  remove: Schema.Array(Schema.String).check(Schema.isUnique()),
  append: Schema.optional(
    Schema.Record(
      Schema.String,
      Schema.Struct({
        baseLength: Schema.Int.check(Schema.isGreaterThanOrEqualTo(0)),
        value: Schema.NonEmptyString,
      }),
    ),
  ),
})
const checkpointSchema = Schema.Struct({
  version: Schema.Literals([1]),
  baseSavedAt: Schema.NullOr(timestampSchema),
  savedAt: timestampSchema,
  order: orderSchema,
  upserts: Schema.Array(
    Schema.Struct({
      thread: metadataSchema,
      messages: Schema.Union([
        Schema.Struct({ mode: Schema.Literals(['replace']), values: Schema.Array(Schema.Unknown) }),
        Schema.Struct({
          mode: Schema.Literals(['patch']),
          order: Schema.optional(orderSchema),
          upserts: Schema.Array(identifiedMessageSchema),
          fields: Schema.optional(Schema.Array(messageFieldSchema)),
        }),
      ]),
    }),
  ),
})
const decodeHistory = Schema.decodeUnknownEffect(historySchema)
const decodeSnapshot = Schema.decodeUnknownEffect(snapshotSchema)
const decodeCheckpoint = Schema.decodeUnknownEffect(checkpointSchema)
const decodeMessages = Schema.decodeUnknownEffect(Schema.Array(identifiedMessageSchema))
const decodeTimestamp = Schema.decodeUnknownEffect(timestampSchema)
const decodeJson = Schema.decodeUnknownEffect(Schema.fromJsonString(Schema.Unknown))

/** Runs entirely in the writer worker. Only a completed atomic replacement advances the base. */
export class ConversationCheckpointEngine {
  private readonly path: string
  private initialized = false
  private initializationError?: PersistenceError
  private snapshot: ConversationHistorySnapshot | null = null
  private encodedSnapshot?: string | Uint8Array<ArrayBuffer>

  constructor(private readonly directory: string) {
    this.path = join(directory, 'conversations.json')
  }

  private error(operation: string, message: string) {
    return new PersistenceError({ operation, path: this.path, message, cause: new Error(message) })
  }

  readonly loadEffect = Effect.fn('ConversationCheckpointEngine.load')(function* (
    this: ConversationCheckpointEngine,
  ) {
    // Explicit recovery reloads may admit an externally repaired original. A
    // save cannot clear this guard, and healthy acknowledged state stays cached.
    if (this.initializationError) this.initializationError = undefined
    yield* this.initializeEffect()
    return this.snapshot
  })

  readonly loadEncodedEffect = Effect.fn('ConversationCheckpointEngine.loadEncoded')(function* (
    this: ConversationCheckpointEngine,
  ) {
    const snapshot = yield* this.loadEffect()
    if (snapshot === null) return null
    // Keep just the current revision's serialization, reusing validated read or
    // commit JSON. Convert it once, then copy bytes so transfers preserve the cache.
    return yield* Effect.try({
      try: () => {
        const encoded =
          this.encodedSnapshot instanceof Uint8Array
            ? this.encodedSnapshot
            : new TextEncoder().encode(this.encodedSnapshot ?? JSON.stringify(snapshot))
        this.encodedSnapshot = encoded
        return encoded.slice().buffer
      },
      catch: (cause) => persistenceError('serialize', this.path, cause),
    })
  })

  readonly saveEffect = Effect.fn('ConversationCheckpointEngine.save')(function* (
    this: ConversationCheckpointEngine,
    threads: unknown[],
    savedAt: number,
  ) {
    yield* decodeHistory(threads).pipe(
      Effect.mapError(() =>
        this.error(
          'validate',
          EffectArray.isArray(threads)
            ? 'Conversation history contains an invalid thread.'
            : 'Conversation history must be an array.',
        ),
      ),
    )
    yield* decodeTimestamp(savedAt).pipe(
      Effect.mapError(() =>
        this.error('validate', 'Conversation checkpoint has an invalid timestamp.'),
      ),
    )
    yield* this.initializeEffect()
    yield* this.commitEffect({ ...this.snapshot, version: 1, savedAt, threads })
    return { savedAt }
  }, Effect.uninterruptible)

  readonly checkpointEffect = Effect.fn('ConversationCheckpointEngine.checkpoint')(function* (
    this: ConversationCheckpointEngine,
    input: unknown,
  ): Effect.fn.Return<ConversationCheckpointAck, PersistenceError> {
    // Canonicalize only the changed wire packet. The committed tree already has
    // JSON semantics, so streaming saves do not parse the complete history again.
    const canonicalInput = yield* Effect.try({
      try: () => JSON.parse(JSON.stringify(input)),
      catch: (cause) => persistenceError('serialize', this.path, cause),
    })
    const checkpoint = yield* decodeCheckpoint(canonicalInput).pipe(
      Effect.mapError((cause) => persistenceError('validate', this.path, cause)),
    )
    yield* this.initializeEffect()
    if (checkpoint.baseSavedAt !== (this.snapshot?.savedAt ?? null))
      return yield* this.error('base', CONVERSATION_CHECKPOINT_BASE_CHANGED)
    if (checkpoint.savedAt <= (checkpoint.baseSavedAt ?? -1))
      return yield* this.error(
        'revision',
        'Conversation checkpoint must advance the durable timestamp.',
      )

    const previous = new Map(
      (this.snapshot?.threads ?? []).map((value) => {
        const thread = value as typeof threadSchema.Type
        return [thread.id, thread] as const
      }),
    )
    if (previous.size !== (this.snapshot?.threads.length ?? 0) || previous.has(''))
      return yield* this.error(
        'identity',
        'Conversation threads require unique nonempty identifiers before incremental updates.',
      )
    const updates = new Map<string, typeof threadSchema.Type>()
    const membership = new Set(checkpoint.order)
    for (const update of checkpoint.upserts) {
      const metadata = update.thread
      if ('messages' in metadata)
        return yield* this.error(
          'validate',
          'Conversation checkpoint metadata must keep messages in the message update.',
        )
      if (!membership.has(metadata.id) || updates.has(metadata.id))
        return yield* this.error(
          'validate',
          'Conversation checkpoint contains a duplicate or unlisted thread update.',
        )
      const current = previous.get(metadata.id)
      if (
        current &&
        update.messages.mode === 'patch' &&
        (current.profileId !== metadata.profileId || current.provider !== metadata.provider)
      )
        return yield* this.error(
          'identity',
          'Conversation checkpoint changed the workspace or provider of an existing thread.',
        )

      let messages: unknown[]
      if (update.messages.mode === 'replace') {
        messages = [...update.messages.values]
      } else {
        if (!current)
          return yield* this.error(
            'base',
            'A new conversation requires complete messages before incremental updates.',
          )
        const priorMessages = yield* decodeMessages(current.messages).pipe(
          Effect.mapError(() =>
            this.error(
              'identity',
              'Conversation messages require unique identifiers before incremental updates.',
            ),
          ),
        )
        const byId = new Map(priorMessages.map((message) => [message.id, message]))
        if (byId.size !== priorMessages.length)
          return yield* this.error(
            'identity',
            'Conversation messages require unique identifiers before incremental updates.',
          )
        const messageOrder = update.messages.order ?? priorMessages.map((message) => message.id)
        const messageMembership = new Set(messageOrder)
        const changed = new Set<string>()
        for (const message of update.messages.upserts) {
          if (!messageMembership.has(message.id) || changed.has(message.id))
            return yield* this.error(
              'validate',
              'Conversation checkpoint contains a duplicate or unlisted message update.',
            )
          changed.add(message.id)
          byId.set(message.id, message)
        }
        for (const fields of update.messages.fields ?? []) {
          if (!messageMembership.has(fields.id) || changed.has(fields.id))
            return yield* this.error(
              'validate',
              'Conversation checkpoint contains a duplicate, overlapping, or unlisted message field update.',
            )
          const message = byId.get(fields.id)
          if (!message)
            return yield* this.error(
              'base',
              'Conversation checkpoint field update refers to a message missing from its durable base.',
            )
          if (
            Object.hasOwn(fields.set, 'id') ||
            fields.remove.includes('id') ||
            Object.hasOwn(fields.append ?? {}, 'id') ||
            fields.remove.some(
              (key) => Object.hasOwn(fields.set, key) || Object.hasOwn(fields.append ?? {}, key),
            ) ||
            Object.keys(fields.append ?? {}).some((key) => Object.hasOwn(fields.set, key))
          )
            return yield* this.error(
              'validate',
              'Conversation checkpoint message fields cannot change identity or overlap set, remove, and append properties.',
            )
          changed.add(fields.id)
          // Object spread creates own data properties, including __proto__;
          // deleting a property stays distinct from assigning JSON null.
          const patched = { ...message, ...fields.set }
          for (const key of fields.remove) Reflect.deleteProperty(patched, key)
          for (const [key, append] of Object.entries(fields.append ?? {})) {
            if (!Object.hasOwn(message, key))
              return yield* this.error(
                'base',
                'Conversation checkpoint append requires an existing own string property.',
              )
            const previous = message[key]
            if (typeof previous !== 'string')
              return yield* this.error(
                'base',
                'Conversation checkpoint append requires an existing own string property.',
              )
            if (previous.length !== append.baseLength)
              return yield* this.error(
                'base',
                'Conversation checkpoint append length differs from its durable string base.',
              )
            Object.defineProperty(patched, key, {
              value: previous + append.value,
              enumerable: true,
              configurable: true,
              writable: true,
            })
          }
          byId.set(fields.id, patched)
        }
        messages = []
        for (const id of messageOrder) {
          const message = byId.get(id)
          if (!message)
            return yield* this.error(
              'base',
              'Conversation checkpoint refers to a message missing from its durable base.',
            )
          messages.push(message)
        }
      }
      updates.set(metadata.id, { ...metadata, messages })
    }
    const threads: unknown[] = []
    for (const id of checkpoint.order) {
      const thread = updates.get(id) ?? previous.get(id)
      if (!thread)
        return yield* this.error(
          'base',
          'Conversation checkpoint refers to a thread missing from its durable base.',
        )
      threads.push(thread)
    }
    yield* this.commitEffect(
      { ...this.snapshot, version: 1, savedAt: checkpoint.savedAt, threads },
      true,
    )
    return { savedAt: checkpoint.savedAt }
  }, Effect.uninterruptible)

  private readonly initializeEffect = Effect.fn('ConversationCheckpointEngine.initialize')(() =>
    this.initializeUncheckedEffect().pipe(
      Effect.tapError((error) =>
        Effect.sync(() => {
          if (error.operation === 'decode' || error.operation === 'validate')
            this.initializationError = error
        }),
      ),
    ),
  )

  private readonly initializeUncheckedEffect = Effect.fnUntraced(function* (
    this: ConversationCheckpointEngine,
  ) {
    if (this.initialized) return
    if (this.initializationError) return yield* this.initializationError
    yield* persistenceIO('mkdir', this.directory, () => mkdir(this.directory, { recursive: true }))
    const serialized = yield* persistenceIO('read', this.path, () =>
      readFile(this.path, 'utf8'),
    ).pipe(
      Effect.catchTag('PersistenceError', (error) =>
        (error.cause as NodeJS.ErrnoException).code === 'ENOENT'
          ? Effect.succeed(null)
          : Effect.fail(error),
      ),
    )
    if (serialized !== null) {
      const decoded = yield* decodeJson(serialized).pipe(
        Effect.mapError((cause) => persistenceError('decode', this.path, cause)),
      )
      if (EffectArray.isArray(decoded)) {
        yield* decodeHistory(decoded).pipe(
          Effect.mapError((cause) => persistenceError('validate', this.path, cause)),
        )
        this.snapshot = { version: 1, savedAt: 0, threads: decoded }
      } else {
        yield* decodeSnapshot(decoded).pipe(
          Effect.mapError(
            (cause) =>
              new PersistenceError({
                operation: 'validate',
                path: this.path,
                cause,
                message: 'Conversation history could not be read. The original file was preserved.',
              }),
          ),
        )
        // Retain original objects, including optional fields unknown to this version.
        this.snapshot = decoded as ConversationHistorySnapshot
        this.encodedSnapshot = serialized
      }
    }
    this.initialized = true
  })

  private readonly commitEffect = Effect.fnUntraced(function* (
    this: ConversationCheckpointEngine,
    snapshot: ConversationHistorySnapshot,
    canonical = false,
  ) {
    const serialized = yield* Effect.try({
      try: () => JSON.stringify(snapshot),
      catch: (cause) => persistenceError('serialize', this.path, cause),
    })
    if (Buffer.byteLength(serialized, 'utf8') > 256 * 1024 * 1024)
      return yield* this.error(
        'validate',
        'Conversation history exceeds the 256 MB checkpoint limit. No history was removed.',
      )
    yield* atomicSnapshot(this.path, serialized)
    // Full saves establish a canonical tree once; compact updates already have
    // JSON semantics and reuse the untouched worker-owned records.
    this.snapshot = canonical ? snapshot : (JSON.parse(serialized) as ConversationHistorySnapshot)
    this.encodedSnapshot = serialized
  })
}
