import type { Message, Thread } from './state'

export interface TurnGroup {
  key: string
  turn: number
  user?: Message
  messages: Message[]
}

/** A steering request belongs to the running turn, not a new artificial response group. */
export function groupThreadTurns(messages: Message[]): TurnGroup[] {
  const groups: TurnGroup[] = []
  const byTurn = new Map<number, TurnGroup>()
  for (const message of messages) {
    let group = byTurn.get(message.turn)
    if (!group) {
      group = { key: `turn:${message.turn}:${message.id}`, turn: message.turn, messages: [] }
      byTurn.set(message.turn, group)
      groups.push(group)
      if (message.role === 'user') {
        group.user = message
        continue
      }
    }
    group.messages.push(message)
  }
  return groups
}

/** Reuse settled turn props while another turn streams, without hiding late child updates. */
export function createTurnGroupProjector(): (messages: Message[]) => TurnGroup[] {
  let previousMessages: Message[] = []
  let previousGroups: TurnGroup[] = []
  const rebuild = (messages: Message[]) => {
    previousMessages = messages
    previousGroups = groupThreadTurns(messages)
    return previousGroups
  }
  return (messages) => {
    if (messages === previousMessages) return previousGroups
    if (!previousMessages.length || messages.length < previousMessages.length)
      return rebuild(messages)
    const changedTurns = new Set<number>()
    for (let index = 0; index < messages.length; index++) {
      const message = messages[index]
      const previous = previousMessages[index]
      if (message === previous) continue
      // Reordering, removing, or replacing IDs can change turn order and its first request.
      if (previous && (previous.id !== message.id || previous.turn !== message.turn))
        return rebuild(messages)
      changedTurns.add(message.turn)
    }
    previousMessages = messages
    if (!changedTurns.size) return previousGroups
    const changedGroups = new Map<number, TurnGroup>()
    for (const message of messages) {
      if (!changedTurns.has(message.turn)) continue
      let group = changedGroups.get(message.turn)
      if (!group) {
        group = { key: `turn:${message.turn}:${message.id}`, turn: message.turn, messages: [] }
        changedGroups.set(message.turn, group)
        if (message.role === 'user') {
          group.user = message
          continue
        }
      }
      group.messages.push(message)
    }
    previousGroups = previousGroups.map((group) => {
      const replacement = changedGroups.get(group.turn)
      changedGroups.delete(group.turn)
      return replacement || group
    })
    previousGroups.push(...changedGroups.values())
    return previousGroups
  }
}

/** Accepted steering is input to the same turn and must not restart its clock. */
export function threadTurnStartedAt(thread: Pick<Thread, 'messages' | 'turn'>): number | undefined {
  let first: Message | undefined
  for (const message of thread.messages) {
    if (message.turn !== thread.turn || message.role !== 'user') continue
    first ||= message
    if (message.submission !== 'steering') return message.createdAt
  }
  return first?.createdAt
}

export function toolLifecycle(
  status?: string,
): 'active' | 'failed' | 'interrupted' | 'completed' | 'unknown' {
  if (!status) return 'completed'
  const value = status.replace(/[_-]/g, '').toLowerCase()
  if (
    [
      'running',
      'inprogress',
      'waiting',
      'pending',
      'pendinginit',
      'queued',
      'spawning',
      'initializing',
      'started',
    ].includes(value)
  )
    return 'active'
  if (['failed', 'errored', 'error'].includes(value)) return 'failed'
  if (
    ['interrupted', 'cancelled', 'canceled', 'stopped', 'killed', 'shutdown', 'declined'].includes(
      value,
    )
  )
    return 'interrupted'
  if (
    ['completed', 'complete', 'done', 'success', 'succeeded', 'exited', 'finished'].includes(value)
  )
    return 'completed'
  return 'unknown'
}

function hasOutstandingActivity(group: TurnGroup): boolean {
  return (
    threadRunningChildIds(group.messages).size > 0 ||
    group.messages.some(
      (message) =>
        (message.kind === 'event' && message.status === 'waiting') ||
        (message.role === 'tool' &&
          message.kind !== 'status' &&
          message.kind !== 'event' &&
          toolLifecycle(message.status) !== 'completed') ||
        ((message.agentId || message.parentItemId || message.kind === 'subagent') &&
          toolLifecycle(message.status) === 'active'),
    )
  )
}

/** Native child lifecycles supersede historical collab-tool snapshots retained in the transcript. */
export function threadRunningChildIds(messages: Message[]): Set<string> {
  const states = new Map<string, string>()
  const lifecycles = new Map<string, string>()
  for (const message of messages) {
    if (message.activityStateUnknown) continue
    if (!message.agentId && !message.parentItemId && message.kind !== 'subagent') continue
    const id = message.agentId || message.parentItemId || message.id
    // A completed child command does not settle the agent that ran it.
    if (
      message.status &&
      (message.kind === 'subagent' || toolLifecycle(message.status) === 'active')
    )
      states.set(id, message.status)
    if (message.kind === 'subagent') {
      // Restored interrupted rows retain old provider details for inspection, not live state.
      if (toolLifecycle(message.status) !== 'interrupted')
        for (const participant of subagentPresentation(message).participants)
          if (participant.status) states.set(participant.id, participant.status)
      if (
        (message.details?.lifecycle === 'turn' ||
          (typeof message.details?.run_id === 'string' && message.details.run_id)) &&
        message.status
      )
        lifecycles.set(id, message.status)
    }
  }
  for (const [id, status] of lifecycles) states.set(id, status)
  return new Set(
    [...states].filter(([, status]) => toolLifecycle(status) === 'active').map(([id]) => id),
  )
}

export function threadHasRunningChildren(thread: Pick<Thread, 'messages' | 'pending'>): boolean {
  return (
    thread.pending.some((request) => Boolean(request.agentId)) ||
    threadRunningChildIds(thread.messages).size > 0
  )
}

/** Never move a response past a tool, steering request, or error. */
export function threadOutputSequence(group: TurnGroup): Message[] {
  return group.messages
}

export type CompletedTurnRow =
  { kind: 'message'; message: Message } | { kind: 'activity'; messages: Message[] }

/** Fold consecutive work in place: expanding it restores the exact original chronology. */
export function completedTurnRows(group: TurnGroup, response: Message): CompletedTurnRow[] {
  const rows: CompletedTurnRow[] = []
  let activity: Extract<CompletedTurnRow, { kind: 'activity' }> | undefined
  for (const message of group.messages) {
    if (
      message.role === 'user' ||
      message === response ||
      (message.role === 'assistant' &&
        !message.kind &&
        message.phase === 'final_answer' &&
        !message.agentId &&
        !message.parentItemId)
    ) {
      activity = undefined
      rows.push({ kind: 'message', message })
    } else {
      if (!activity) {
        activity = { kind: 'activity', messages: [] }
        rows.push(activity)
      }
      activity.messages.push(message)
    }
  }
  return rows
}

/** Use only reported command input or the provider's tool title for a compact live action. */
export function toolActionSummary(message: Message): string {
  let input: Record<string, unknown> = {}
  try {
    input = record(JSON.parse(message.input || 'null'))
  } catch {
    /* Raw input stays in details. */
  }
  const title = message.title?.trim() || 'Agent tool'
  const command = /^(Bash|Shell|Terminal|exec_command|execute_command|commandExecution)$/i.test(
    title,
  )
    ? text(input.cmd) || text(input.command)
    : undefined
  const action = (command || title).split(/\r?\n/, 1)[0].trim()
  const label = `${action.slice(0, 160)}${action.length > 160 ? '…' : ''}`
  const lifecycle = toolLifecycle(message.status)
  const verb = ['waiting', 'pending', 'queued'].includes((message.status || '').toLowerCase())
    ? 'Waiting for'
    : lifecycle === 'active'
      ? 'Running'
      : lifecycle === 'failed'
        ? 'Failed'
        : lifecycle === 'interrupted'
          ? 'Interrupted'
          : lifecycle === 'completed'
            ? 'Ran'
            : 'Tool'
  return `${verb} ${label}`
}

/** Keep live and unsuccessful work visible; only a completed parent response replaces activity. */
export function completedTurnResponse(
  group: TurnGroup,
  busy: boolean,
  turnStatus?: string,
): Message | undefined {
  if (
    busy ||
    hasOutstandingActivity(group) ||
    group.messages.some(
      (message) => message.role === 'error' && message.details?.recoverable !== true,
    )
  )
    return undefined
  const responses = group.messages.filter(
    (message) =>
      message.role === 'assistant' &&
      !message.agentId &&
      !message.parentItemId &&
      !message.kind &&
      (message.text.trim() || message.attachments?.length || message.sourceChange),
  )
  const final = responses.filter((message) => message.phase === 'final_answer').at(-1)
  const response = final || responses.filter((message) => message.phase !== 'commentary').at(-1)
  const status = turnStatus || group.user?.finishStatus || response?.finishStatus
  return (status ? status === 'completed' : Boolean(final)) ? response : undefined
}

export function isProgressUpdate(message: Message): boolean {
  return (
    message.role === 'assistant' &&
    !message.kind &&
    !message.agentId &&
    !message.parentItemId &&
    message.phase !== 'final_answer'
  )
}

/** Summaries use reported action text instead of exposing reasoning labels or provider metadata. */
const cachedActivitySummaries = new WeakMap<Message, string>()
export function activitySummary(message: Message): string {
  const cached = cachedActivitySummaries.get(message)
  if (cached !== undefined) return cached
  let summary: string
  const title = message.title?.trim()
  if (message.kind === 'plan') summary = 'Updated the plan'
  else if (title && !/^reasoning(?: summary)?$/i.test(title)) summary = title
  else {
    summary = 'Agent activity'
    let start = 0
    while (start < message.text.length) {
      const newline = message.text.indexOf('\n', start)
      const end = newline < 0 ? message.text.length : newline
      const line = message.text
        .slice(start, end)
        .replace(/^\s*(?:#{1,6}\s+|[-*]\s+)|[*`]/g, '')
        .trim()
      if (line) {
        summary = `${line.slice(0, 120)}${line.length > 120 ? '…' : ''}`
        break
      }
      if (newline < 0) break
      start = newline + 1
    }
  }
  cachedActivitySummaries.set(message, summary)
  return summary
}

/** The finder only links to messages that are mounted in the preview timeline. */
export function previewNavigableMessages(thread: Thread): Message[] {
  return groupThreadTurns(thread.messages).flatMap((group) => {
    const response = completedTurnResponse(
      group,
      thread.busy && group.turn === thread.turn,
      group.turn === thread.turn ? thread.turnStatus : undefined,
    )
    return [
      ...(group.user ? [group.user] : []),
      ...(response
        ? completedTurnRows(group, response).flatMap((row) =>
            row.kind === 'message' ? [row.message] : [],
          )
        : group.messages.filter(
            (message) =>
              message.role === 'user' ||
              isProgressUpdate(message) ||
              (message.role === 'assistant' &&
                !message.kind &&
                !message.agentId &&
                !message.parentItemId &&
                message.phase === 'final_answer'),
          )),
    ]
  })
}

export function messagePhaseLabel(message: Message): string | undefined {
  if (message.kind === 'reasoning') return 'Reasoning summary'
  if (message.kind === 'plan') return 'Plan'
  if (message.phase === 'commentary') return 'Progress update'
  if (message.phase === 'final_answer') return 'Response'
  return undefined
}

export interface PlanStep {
  text: string
  status?: string
}
export function providerPlanSteps(message: Message): PlanStep[] {
  if (message.kind !== 'plan') return []
  const value = message.details?.plan || message.details?.steps
  if (!Array.isArray(value)) return []
  return value.flatMap((value) => {
    const step = record(value)
    const label = text(step.step) || text(step.text) || text(step.content)
    return label ? [{ text: label, status: text(step.status) }] : []
  })
}

export interface ToolOutputSection {
  label: 'Input' | 'Output' | 'Provider details'
  text: string
}
const serializedDetails = new WeakMap<Record<string, unknown>, string>()
export function toolOutputSections(message: Message): ToolOutputSection[] {
  const sections: ToolOutputSection[] = []
  if (message.input) sections.push({ label: 'Input', text: message.input })
  if (message.text && message.text !== message.input)
    sections.push({ label: 'Output', text: message.text })
  if (message.details && Object.keys(message.details).length) {
    let text = serializedDetails.get(message.details)
    if (text === undefined) {
      text = JSON.stringify(message.details, null, 2)
      serializedDetails.set(message.details, text)
    }
    if (text !== message.text && text !== message.input)
      sections.push({ label: 'Provider details', text })
  }
  return sections
}

export interface OutputPreview {
  text: string
  shortened: boolean
  characters: number
}
/** Mount very large raw bodies only on demand; their exact text remains copyable/exportable. */
export function outputPreview(text: string, limit = 6000): OutputPreview {
  limit = Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : 6000
  if (text.length <= limit && text.split('\n').length <= 30)
    return { text, shortened: false, characters: text.length }
  const head = Math.floor(limit * 0.7)
  const tail = limit - head
  const beginning = text.slice(0, head).split('\n').slice(0, 20).join('\n')
  const ending = tail ? text.slice(-tail).split('\n').slice(-10).join('\n') : ''
  return {
    text: `${beginning}\n\n… ${Math.max(0, text.length - beginning.length - ending.length).toLocaleString()} characters in the full output …\n\n${ending}`,
    shortened: true,
    characters: text.length,
  }
}

const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {}
const text = (value: unknown): string | undefined =>
  typeof value === 'string' && value.trim() ? value : undefined
function parseInput(message: Message): Record<string, unknown> {
  try {
    return record(JSON.parse(message.input || '{}'))
  } catch {
    return {}
  }
}

export interface SubagentPresentation {
  name: string
  id?: string
  parentItemId?: string
  task?: string
  status: string
  participants: { id: string; name: string; status?: string; message?: string }[]
}
export function subagentPresentation(message: Message): SubagentPresentation {
  const input = parseInput(message)
  const details = record(message.details)
  const id = message.agentId || text(input.agent_id) || text(input.id) || text(details.agentId)
  const name =
    message.agentName ||
    text(input.task_name) ||
    text(input.name) ||
    text(input.description) ||
    text(input.subagent_type) ||
    text(details.agentName) ||
    id ||
    message.title ||
    'Subagent'
  const states = record(details.agentsStates || details.agents_states || details.agents)
  const participants = Object.entries(states).map(([id, value]) => {
    const state = record(value)
    return {
      id,
      name: text(state.agentName) || text(state.name) || id,
      status: text(state.status) || (typeof value === 'string' ? value : undefined),
      message: text(state.message) || text(state.result) || text(state.output),
    }
  })
  return {
    name,
    id,
    parentItemId: message.parentItemId,
    task:
      text(input.prompt) || text(input.message) || text(details.prompt) || text(details.message),
    status: message.status || 'completed',
    participants,
  }
}

/** Stable DOM anchors link nested provider activity without using untrusted IDs as selectors. */
export function activityAnchor(messageId: string): string {
  return `activity-${encodeURIComponent(messageId)}`
}
