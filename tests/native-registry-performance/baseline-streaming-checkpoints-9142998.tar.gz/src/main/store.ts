import { mkdir, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { Effect, Option, Predicate, Schema, Semaphore } from 'effect'
import type { ConnectionProfile } from '../shared/types'
import { profileSchema } from '../shared/validation'
import { runEffect } from './effect-runtime'
import { atomicSnapshot, persistenceError, persistenceIO } from './persistence-effects'

interface Data {
  profiles: ConnectionProfile[]
  knownHosts: Record<string, string>
}

const storedData = Schema.fromJsonString(
  Schema.Struct({
    profiles: Schema.optional(Schema.Array(Schema.Unknown)),
    knownHosts: Schema.optional(Schema.Unknown),
  }),
)
const decodeStoredData = Schema.decodeUnknownEffect(storedData)
const decodeKnownHosts = Schema.decodeUnknownOption(Schema.Record(Schema.String, Schema.Unknown))

export class Store {
  private data: Data = { profiles: [], knownHosts: {} }
  private readonly lock = Semaphore.makeUnsafe(1)
  constructor(private directory: string) {}

  init() {
    return runEffect(this.initEffect())
  }

  readonly initEffect = Effect.fn('Store.init')(function* (this: Store) {
    yield* persistenceIO('mkdir', this.directory, () => mkdir(this.directory, { recursive: true }))
    const path = join(this.directory, 'connections.json')
    const serialized = yield* persistenceIO('read', path, () => readFile(path, 'utf8')).pipe(
      Effect.catchTag('PersistenceError', (error) =>
        (error.cause as NodeJS.ErrnoException).code === 'ENOENT'
          ? Effect.succeed(null)
          : Effect.fail(error),
      ),
    )
    if (serialized === null) return
    const raw = yield* decodeStoredData(serialized).pipe(
      Effect.mapError((cause) => persistenceError('decode', path, cause)),
    )
    const knownHosts = Option.getOrElse(decodeKnownHosts(raw.knownHosts), () => ({}))
    this.data = {
      profiles: (raw.profiles ?? []).flatMap((p) => {
        const parsed = profileSchema.safeParse(p)
        return parsed.success ? [parsed.data] : []
      }),
      knownHosts: Object.fromEntries(
        Object.entries(knownHosts).filter((entry): entry is [string, string] =>
          Predicate.isString(entry[1]),
        ),
      ),
    }
  })

  list() {
    return structuredClone(this.data.profiles)
  }
  save(profile: ConnectionProfile) {
    const clean = profileSchema.parse(profile)
    return runEffect(this.saveProfileEffect(clean))
  }
  saveEffect(profile: ConnectionProfile) {
    return this.decodeProfileEffect(profile).pipe(
      Effect.flatMap((clean) => this.saveProfileEffect(clean)),
    )
  }
  private saveProfileEffect(profile: ConnectionProfile) {
    return this.exclusive(
      Effect.suspend(() =>
        this.commitEffect({
          ...this.data,
          profiles: [...this.data.profiles.filter((p) => p.id !== profile.id), profile],
        }),
      ),
    )
  }
  /** Publish a selected project only while the renderer that requested it still owns it. */
  saveIfCurrent(profile: ConnectionProfile, current: () => boolean, onCommit: () => void) {
    const clean = profileSchema.parse(profile)
    return runEffect(this.saveCurrentProfileEffect(clean, current, onCommit))
  }
  saveIfCurrentEffect(profile: ConnectionProfile, current: () => boolean, onCommit: () => void) {
    return this.decodeProfileEffect(profile).pipe(
      Effect.flatMap((clean) => this.saveCurrentProfileEffect(clean, current, onCommit)),
    )
  }
  private saveCurrentProfileEffect(
    profile: ConnectionProfile,
    current: () => boolean,
    onCommit: () => void,
  ) {
    const store = this
    return this.exclusive(
      Effect.gen(function* () {
        if (!current()) return false
        const previous = store.data
        const next = {
          ...previous,
          profiles: [...previous.profiles.filter((p) => p.id !== profile.id), profile],
        }
        if (!(yield* store.writeEffect(next, current))) return false
        if (!current()) {
          // Cancellation can arrive while the atomic rename is in flight. Restore
          // the last committed snapshot before releasing the serialized write lock.
          yield* store.writeEffect(previous)
          return false
        }
        store.data = next
        onCommit()
        return true
      }),
    )
  }
  remove(id: string) {
    return runEffect(this.removeEffect(id))
  }
  removeEffect(id: string) {
    return this.exclusive(
      Effect.suspend(() =>
        this.commitEffect({
          ...this.data,
          profiles: this.data.profiles.filter((p) => p.id !== id),
        }),
      ),
    )
  }
  hostKey(host: string) {
    return Object.hasOwn(this.data.knownHosts, host) ? this.data.knownHosts[host] : undefined
  }
  trust(host: string, fingerprint: string) {
    return runEffect(this.trustEffect(host, fingerprint))
  }
  trustEffect(host: string, fingerprint: string) {
    return this.exclusive(
      Effect.suspend(() =>
        this.commitEffect({
          ...this.data,
          knownHosts: { ...this.data.knownHosts, [host]: fingerprint },
        }),
      ),
    )
  }
  settled() {
    return runEffect(this.settledEffect())
  }
  settledEffect() {
    // Waiting for a permit survives failed operations and includes their scoped
    // cleanup before recovery can observe the committed state.
    return this.lock.withPermit(Effect.void)
  }

  private exclusive<A, E>(operation: Effect.Effect<A, E>) {
    return this.lock.withPermit(Effect.uninterruptible(operation))
  }
  private decodeProfileEffect(profile: ConnectionProfile) {
    return Effect.try({
      try: () => profileSchema.parse(profile),
      catch: (cause) => persistenceError('validate-profile', this.directory, cause),
    })
  }
  private readonly commitEffect = Effect.fnUntraced(function* (this: Store, next: Data) {
    yield* this.writeEffect(next)
    this.data = next
  })
  private writeEffect(data: Data, current?: () => boolean) {
    const path = join(this.directory, 'connections.json')
    return atomicSnapshot(path, JSON.stringify(data, null, 2), current)
  }
}
