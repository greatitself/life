/** A committed history checkpoint. A missing store is distinct from an intentionally empty one. */
export interface ConversationHistorySnapshot {
  version: 1
  savedAt: number
  threads: unknown[]
}

export const CONVERSATION_CHECKPOINT_BASE_CHANGED = 'CONVERSATION_CHECKPOINT_BASE_CHANGED'

export interface ConversationCheckpointThread extends Record<string, unknown> {
  id: string
  profileId: string
  provider: 'codex' | 'claude'
}

/** Exact own-property edits for an existing message, preserving omitted body fields. */
export interface ConversationMessageFieldCheckpoint {
  id: string
  set: Record<string, unknown>
  remove: string[]
  /** Exact UTF-16 suffixes, admitted only by bridges advertising append support. */
  append?: Record<string, { baseLength: number; value: string }>
}

export type ConversationMessageCheckpoint =
  | { mode: 'replace'; values: unknown[] }
  | {
      mode: 'patch'
      order?: string[]
      upserts: unknown[]
      fields?: ConversationMessageFieldCheckpoint[]
    }

/** An exact change from an acknowledged native checkpoint, including deletion and ordering. */
export interface ConversationCheckpointInput {
  version: 1
  baseSavedAt: number | null
  savedAt: number
  order: string[]
  upserts: { thread: ConversationCheckpointThread; messages: ConversationMessageCheckpoint }[]
}

export interface ConversationCheckpointAck {
  savedAt: number
}
