import { join } from 'node:path'
import { Deferred, Effect, Exit, Fiber, Option, Schema, Scope, Semaphore } from 'effect'
import type {
  ConversationCheckpointAck,
  ConversationHistorySnapshot,
} from '../shared/conversations'
import { runEffect } from './effect-runtime'
import { persistenceError } from './persistence-effects'
import type { PersistenceError } from './persistence-effects'
import {
  workerCheckpointTransport,
  type CheckpointCommand,
  type ConversationCheckpointTransport,
} from './conversation-checkpoint-transport'

interface PendingWrite {
  command: Exclude<CheckpointCommand, { type: 'load' | 'loadEncoded' }>
  subscribers: Set<Deferred.Deferred<ConversationCheckpointAck, PersistenceError>>
}

// Only this constant-size discriminator is inspected on the main thread.
const decodeBase = Schema.decodeUnknownOption(
  Schema.Struct({
    version: Schema.Literals([1]),
    baseSavedAt: Schema.NullOr(Schema.Int.check(Schema.isGreaterThanOrEqualTo(0))),
  }),
)

function canCoalesce(previous: PendingWrite['command'], next: PendingWrite['command']): boolean {
  if (previous.type === 'save' && next.type === 'save') return true
  if (previous.type !== 'checkpoint' || next.type !== 'checkpoint') return false
  const priorBase = decodeBase(previous.input)
  const nextBase = decodeBase(next.input)
  return (
    Option.isSome(priorBase) &&
    Option.isSome(nextBase) &&
    priorBase.value.baseSavedAt === nextBase.value.baseSavedAt
  )
}

export interface ConversationStoreOptions {
  workerPath?: string
  /** A scoped transport allows deterministic domain tests without replacing worker ownership in production. */
  transport?: Effect.Effect<
    ConversationCheckpointTransport['Service'],
    PersistenceError,
    Scope.Scope
  >
}

/** One scoped worker, one active write and one coalesced pending checkpoint. */
export class ConversationStore {
  private readonly path: string
  private readonly scope = Scope.makeUnsafe()
  private readonly closeLock = Semaphore.makeUnsafe(1)
  private readonly requestLock = Semaphore.makeUnsafe(1)
  private transport?: ConversationCheckpointTransport['Service']
  private transportScope?: Scope.Closeable
  private pending?: PendingWrite
  private draining?: Fiber.Fiber<void>
  private closed = false

  constructor(
    private readonly directory: string,
    private readonly options: ConversationStoreOptions = {},
  ) {
    this.path = join(directory, 'conversations.json')
  }

  load(): Promise<ConversationHistorySnapshot | null> {
    return runEffect(this.loadEffect())
  }

  readonly loadEffect = Effect.fn('ConversationStore.load')(function* (this: ConversationStore) {
    if (this.closed)
      return yield* persistenceError(
        'closed',
        this.path,
        new Error('Conversation store is closed.'),
      )
    yield* this.settledEffect()
    return (yield* this.executeEffect({ type: 'load' })) as ConversationHistorySnapshot | null
  })

  loadEncoded(): Promise<ArrayBuffer | null> {
    return runEffect(this.loadEncodedEffect())
  }

  readonly loadEncodedEffect = Effect.fn('ConversationStore.loadEncoded')(function* (
    this: ConversationStore,
  ) {
    if (this.closed)
      return yield* persistenceError(
        'closed',
        this.path,
        new Error('Conversation store is closed.'),
      )
    yield* this.settledEffect()
    return (yield* this.executeEffect({ type: 'loadEncoded' })) as ArrayBuffer | null
  })

  save(threads: unknown[], savedAt = Date.now()): Promise<void> {
    return runEffect(this.saveEffect(threads, savedAt))
  }

  readonly saveEffect = Effect.fn('ConversationStore.save')(function* (
    this: ConversationStore,
    threads: unknown[],
    savedAt = Date.now(),
  ) {
    yield* this.enqueueEffect({ type: 'save', threads, savedAt })
  })

  saveCheckpoint(input: unknown): Promise<ConversationCheckpointAck> {
    return runEffect(this.saveCheckpointEffect(input))
  }

  readonly saveCheckpointEffect = Effect.fn('ConversationStore.saveCheckpoint')(function* (
    this: ConversationStore,
    input: unknown,
  ) {
    return yield* this.enqueueEffect({ type: 'checkpoint', input })
  })

  private readonly enqueueEffect = Effect.fnUntraced(function* (
    this: ConversationStore,
    command: PendingWrite['command'],
  ) {
    if (this.closed)
      return yield* persistenceError(
        'closed',
        this.path,
        new Error('Conversation store is closed.'),
      )
    const checkpoint = this.pending ?? {
      command,
      subscribers: new Set<Deferred.Deferred<ConversationCheckpointAck, PersistenceError>>(),
    }
    if (this.pending && !canCoalesce(checkpoint.command, command))
      return yield* persistenceError(
        'queue',
        this.path,
        new Error(
          'A conversation checkpoint with a different base is already queued. Retry after the active checkpoint.',
        ),
      )
    const completion = yield* Deferred.make<ConversationCheckpointAck, PersistenceError>()
    checkpoint.command = command
    checkpoint.subscribers.add(completion)
    this.pending = checkpoint
    if (!this.draining)
      this.draining = yield* Effect.forkIn(this.drainEffect(), this.scope, {
        startImmediately: false,
      })
    // Interruption detaches the waiter while the scoped drain retains the accepted write.
    return yield* Deferred.await(completion).pipe(
      Effect.ensuring(
        Effect.sync(() => {
          checkpoint.subscribers.delete(completion)
        }),
      ),
    )
  })

  settled(): Promise<void> {
    return runEffect(this.settledEffect())
  }

  readonly settledEffect = Effect.fnUntraced(function* (this: ConversationStore) {
    while (this.draining) yield* Fiber.await(this.draining)
  })

  close(): Promise<void> {
    return runEffect(this.closeEffect())
  }

  readonly closeEffect = Effect.fn('ConversationStore.close')(() =>
    this.closeLock.withPermit(
      Effect.gen({ self: this }, function* () {
        this.closed = true
        yield* this.settledEffect()
        yield* this.requestLock.withPermit(Scope.close(this.scope, Exit.void))
      }).pipe(Effect.uninterruptible),
    ),
  )

  private readonly executeEffect = Effect.fn('ConversationStore.execute')(
    (command: CheckpointCommand) =>
      this.requestLock.withPermit(
        Effect.gen({ self: this }, function* () {
          if (!this.transport) {
            const scope = yield* Scope.fork(this.scope)
            const acquired = yield* Effect.exit(
              (
                this.options.transport ??
                workerCheckpointTransport(this.directory, this.options.workerPath)
              ).pipe(Effect.provideService(Scope.Scope, scope)),
            )
            if (Exit.isFailure(acquired)) {
              yield* Scope.close(scope, acquired)
              return yield* acquired
            }
            this.transport = acquired.value
            this.transportScope = scope
          }
          return yield* this.transport.execute(command).pipe(
            Effect.tapError((error) =>
              Effect.gen({ self: this }, function* () {
                if (error.operation !== 'worker') return
                const scope = this.transportScope
                this.transport = undefined
                this.transportScope = undefined
                // Closing the child detaches its finalizers, keeping repeated startup retries bounded.
                if (scope) yield* Scope.close(scope, Exit.void)
              }),
            ),
          )
        }),
      ),
  )

  private readonly drainEffect = Effect.fnUntraced(function* (this: ConversationStore) {
    yield* Effect.yieldNow
    while (this.pending) {
      const checkpoint = this.pending
      this.pending = undefined
      const exit = yield* Effect.exit(
        this.executeEffect(checkpoint.command).pipe(
          Effect.map((value) => value as ConversationCheckpointAck),
        ),
      )
      for (const completion of checkpoint.subscribers) yield* Deferred.done(completion, exit)
      checkpoint.subscribers.clear()
    }
    this.draining = undefined
  })
}
